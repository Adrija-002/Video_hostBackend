started creating this backend project at 1:57 am 2nd june while watching ucl final lol
